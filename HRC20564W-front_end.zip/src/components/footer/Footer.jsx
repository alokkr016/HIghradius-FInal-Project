import React from "react";
import "./Footer.css";

function Footer() {
  return <div className="footer">Copyright 2022 Highradius.All Rights Reserved.</div>;
}

export default Footer;
